# UZ Online TV — Admin Security

The current mobile project now has a login-gated Admin screen for testing.

Demo credentials:
- Username: `admin`
- Password: `UZTV2026`

Important: these credentials are only for local/demo testing. They must NOT be used as production credentials. For the real release, authentication must be handled by the backend (for example Supabase Auth or another secure auth service), with role-based access for editors/admins.

Next production security tasks:
1. Create admin users in the backend.
2. Enable email/password or magic-link authentication.
3. Restrict news/program writes to authenticated admin/editor roles.
4. Add image upload storage.
5. Add push notification service.
