# UZ Online TV — Supabase Setup (V9)

## 1. Create the Supabase project
Create a new Supabase project and keep the Project URL and keys private.

## 2. Run database SQL
In Supabase SQL Editor, run these files in order:
1. `supabase_schema.sql`
2. `supabase_production.sql`

## 3. Create Storage bucket
Create a Storage bucket named `news-images` and set it to **Public** because the backend returns public image URLs.

Do NOT put the Supabase service-role key in the mobile app.

## 4. Create the first admin user
In Supabase Dashboard → Authentication → Users, create an email/password user.
Then run:

```sql
insert into admin_profiles(user_id, role, active)
values ('PASTE_USER_UUID_HERE', 'admin', true)
on conflict (user_id) do update set role='admin', active=true;
```

## 5. Backend environment
Copy `backend/.env.example` to `backend/.env` and fill in:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_STORAGE_BUCKET=news-images`
- optional `EXPO_ACCESS_TOKEN`
- `ALLOWED_ORIGINS`

The service-role key belongs ONLY on the backend server.

## 6. Start backend locally
```bash
cd backend
npm install
npm start
```

Health check:
```bash
curl http://localhost:8080/health
```
Expected:
```json
{"ok":true,"station":"UZ Online TV"}
```

## 7. Connect the mobile app
Set:
```env
EXPO_PUBLIC_API_BASE_URL=https://YOUR-BACKEND-DOMAIN
```
Then restart Expo.

## 8. Android build
After signing into an Expo account and configuring EAS:
```bash
npm install
npx eas login
npx eas build:configure
npx eas build --platform android --profile preview
```
Preview creates an installable APK. For Play Store:
```bash
npx eas build --platform android --profile production
```

A real APK cannot be produced from this source until the build is run under an Expo/EAS account.
