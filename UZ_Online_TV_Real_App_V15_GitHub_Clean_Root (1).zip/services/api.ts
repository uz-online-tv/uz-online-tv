import AsyncStorage from "@react-native-async-storage/async-storage";

export const API_BASE_URL = (process.env.EXPO_PUBLIC_API_BASE_URL || "").replace(/\/$/, "");

export type NewsItem = {
  id: string | number;
  title: string;
  body?: string;
  cat: "Local" | "Politics" | "Sports";
  imageUrl?: string;
  time?: string;
  publishedAt?: string;
};

async function authHeaders(extra: Record<string, string> = {}) {
  const raw = await AsyncStorage.getItem("uz_admin_session");
  const session = raw ? JSON.parse(raw) : null;
  return { "Content-Type": "application/json", ...(session?.accessToken ? { Authorization: `Bearer ${session.accessToken}` } : {}), ...extra };
}

export async function getNews(category?: string): Promise<NewsItem[]> {
  if (!API_BASE_URL) {
    const saved = await AsyncStorage.getItem("uz_news");
    return saved ? JSON.parse(saved) : [];
  }
  const url = category && category !== "All" ? `${API_BASE_URL}/news?category=${encodeURIComponent(category)}` : `${API_BASE_URL}/news`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to load news");
  return res.json();
}

export async function publishNews(item: Omit<NewsItem, "id">) {
  if (!API_BASE_URL) {
    const saved = await getNews();
    const next = [{ ...item, id: Date.now() }, ...saved];
    await AsyncStorage.setItem("uz_news", JSON.stringify(next));
    return next[0];
  }
  const res = await fetch(`${API_BASE_URL}/news`, { method: "POST", headers: await authHeaders(), body: JSON.stringify(item) });
  if (!res.ok) throw new Error((await res.json().catch(() => null))?.error || "Failed to publish news");
  return res.json();
}

export async function getPrograms() {
  if (!API_BASE_URL) {
    const saved = await AsyncStorage.getItem("uz_programs");
    return saved ? JSON.parse(saved) : [];
  }
  const res = await fetch(`${API_BASE_URL}/programs`);
  if (!res.ok) throw new Error("Failed to load programs");
  return res.json();
}

export async function addProgram(item: { day: string; time: string; title: string; description?: string }) {
  if (!API_BASE_URL) {
    const saved = await getPrograms();
    const next = [...saved, { ...item, id: Date.now() }];
    await AsyncStorage.setItem("uz_programs", JSON.stringify(next));
    return next[next.length - 1];
  }
  const res = await fetch(`${API_BASE_URL}/programs`, { method: "POST", headers: await authHeaders(), body: JSON.stringify(item) });
  if (!res.ok) throw new Error((await res.json().catch(() => null))?.error || "Failed to add program");
  return res.json();
}

export async function uploadNewsImage(uri: string) {
  if (!API_BASE_URL) return uri;
  const form = new FormData();
  form.append("file", { uri, name: `news-${Date.now()}.jpg`, type: "image/jpeg" } as any);
  const raw = await AsyncStorage.getItem("uz_admin_session");
  const session = raw ? JSON.parse(raw) : null;
  const res = await fetch(`${API_BASE_URL}/images/news`, {
    method: "POST",
    headers: session?.accessToken ? { Authorization: `Bearer ${session.accessToken}` } : {},
    body: form,
  });
  if (!res.ok) throw new Error((await res.json().catch(() => null))?.error || "An kasa upload hoto.");
  return (await res.json()).url as string;
}
