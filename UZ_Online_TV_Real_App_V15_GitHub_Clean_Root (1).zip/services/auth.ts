import AsyncStorage from "@react-native-async-storage/async-storage";

const API_BASE_URL = (process.env.EXPO_PUBLIC_API_BASE_URL || "").replace(/\/$/, "");

export type AdminSession = {
  accessToken: string;
  refreshToken?: string;
  user: { id: string; email: string; role: "admin" | "editor" };
};

export async function adminSignIn(email: string, password: string): Promise<AdminSession> {
  if (!email || !password) throw new Error("Email da password suna da muhimmanci.");
  if (!API_BASE_URL) {
    if (email === "admin" && password === "UZTV2026") {
      const session: AdminSession = { accessToken: "LOCAL-DEMO-TOKEN", user: { id: "local-admin", email: "admin", role: "admin" } };
      await AsyncStorage.setItem("uz_admin_session", JSON.stringify(session));
      return session;
    }
    throw new Error("Username ko password ba daidai ba.");
  }
  const response = await fetch(`${API_BASE_URL}/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error || "Login ya kasa.");
  await AsyncStorage.setItem("uz_admin_session", JSON.stringify(payload));
  return payload;
}

export async function getAdminSession(): Promise<AdminSession | null> {
  const value = await AsyncStorage.getItem("uz_admin_session");
  return value ? JSON.parse(value) : null;
}

export async function adminSignOut() {
  await AsyncStorage.removeItem("uz_admin_session");
}
