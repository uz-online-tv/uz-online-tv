# UZ Online TV — Backend Plan

Current phase: local demo CMS.

Production endpoints to connect:
- GET /news
- POST /news
- GET /programs
- POST /programs
- GET /videos
- GET /breaking-news
- POST /push-token
- GET /live

Production data should include news title/body/category/image/publishedAt, programs, videos, breaking news, push tokens, and live stream URL.
