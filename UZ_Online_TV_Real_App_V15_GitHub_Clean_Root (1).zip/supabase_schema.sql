
-- UZ Online TV production database schema
create table if not exists news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text,
  category text not null check (category in ('Local','Politics','Sports')),
  image_url text,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists programs (
  id uuid primary key default gen_random_uuid(),
  day text not null,
  time text not null,
  title text not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  thumbnail_url text,
  video_url text not null,
  published_at timestamptz not null default now()
);

create table if not exists breaking_news (
  id uuid primary key default gen_random_uuid(),
  text text not null,
  active boolean not null default true,
  published_at timestamptz not null default now()
);

create table if not exists app_settings (
  key text primary key,
  value text not null
);

-- Useful starting settings
insert into app_settings(key, value)
values
 ('station_name', 'UZ Online TV'),
 ('facebook_url', 'https://www.facebook.com/share/1JqvGaK6U3/?mibextid=wwXIfr'),
 ('live_stream_url', '')
on conflict (key) do nothing;
