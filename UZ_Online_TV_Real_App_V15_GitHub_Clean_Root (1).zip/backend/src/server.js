import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import { createClient } from '@supabase/supabase-js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 }, fileFilter: (_req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  cb(null, allowed.includes(file.mimetype));
} });
const PORT = Number(process.env.PORT || 8080);
const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const BUCKET = process.env.SUPABASE_STORAGE_BUCKET || 'news-images';
const EXPO_ACCESS_TOKEN = process.env.EXPO_ACCESS_TOKEN || '';
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '*').split(',').map(x => x.trim()).filter(Boolean);

if (!SUPABASE_URL || !SERVICE_KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

const adminClient = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { autoRefreshToken: false, persistSession: false } });
app.use(cors({ origin: allowedOrigins.includes('*') ? true : allowedOrigins }));
app.use(express.json({ limit: '2mb' }));
app.disable('x-powered-by');
app.use(rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false }));

const authClient = (token) => createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
  global: { headers: { Authorization: `Bearer ${token}` } }
});

async function requireUser(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Missing access token' });
  const client = authClient(token);
  const { data: { user }, error } = await client.auth.getUser(token);
  if (error || !user) return res.status(401).json({ error: 'Invalid access token' });
  const { data: profile } = await adminClient.from('admin_profiles').select('role,active').eq('user_id', user.id).maybeSingle();
  if (!profile?.active || !['admin', 'editor'].includes(profile.role)) return res.status(403).json({ error: 'Admin access required' });
  req.user = user;
  req.role = profile.role;
  next();
}

function requireAdmin(req, res, next) {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin role required' });
  next();
}

app.get('/health', (_req, res) => res.json({ ok: true, station: 'UZ Online TV' }));

app.post('/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email da password suna da muhimmanci.' });
  const { data, error } = await adminClient.auth.signInWithPassword({ email, password });
  if (error || !data.session || !data.user) return res.status(401).json({ error: 'Login ya kasa.' });
  const { data: profile } = await adminClient.from('admin_profiles').select('role,active').eq('user_id', data.user.id).maybeSingle();
  if (!profile?.active || !['admin', 'editor'].includes(profile.role)) return res.status(403).json({ error: 'Ba a ba wannan account izinin admin ba.' });
  res.json({ accessToken: data.session.access_token, refreshToken: data.session.refresh_token, user: { id: data.user.id, email: data.user.email, role: profile.role } });
});

app.get('/news', async (req, res) => {
  let query = adminClient.from('news').select('id,title,body,category,image_url,published_at').order('published_at', { ascending: false });
  if (req.query.category && req.query.category !== 'All') query = query.eq('category', req.query.category);
  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json((data || []).map(n => ({ id: n.id, title: n.title, body: n.body, cat: n.category, imageUrl: n.image_url, publishedAt: n.published_at, time: 'Yau' })));
});

app.post('/news', requireUser, async (req, res) => {
  const { title, body, cat, imageUrl } = req.body || {};
  if (!title || !cat) return res.status(400).json({ error: 'Title da category suna da muhimmanci.' });
  const { data, error } = await adminClient.from('news').insert({ title, body: body || null, category: cat, image_url: imageUrl || null }).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json({ id: data.id, title: data.title, body: data.body, cat: data.category, imageUrl: data.image_url, publishedAt: data.published_at, time: 'Yanzu' });
});

app.get('/programs', async (_req, res) => {
  const { data, error } = await adminClient.from('programs').select('id,day,time,title,description').order('created_at', { ascending: true });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data || []);
});

app.post('/programs', requireUser, async (req, res) => {
  const { day, time, title, description } = req.body || {};
  if (!day || !time || !title) return res.status(400).json({ error: 'Day, time da title suna da muhimmanci.' });
  const { data, error } = await adminClient.from('programs').insert({ day, time, title, description: description || null }).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/images/news', requireUser, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Ba a turo hoto mai inganci ba. JPG, PNG ko WebP kawai.' });
  const ext = (req.file.originalname.split('.').pop() || 'jpg').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'jpg';
  const path = `news/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await adminClient.storage.from(BUCKET).upload(path, req.file.buffer, { contentType: req.file.mimetype || 'image/jpeg', upsert: false });
  if (error) return res.status(500).json({ error: error.message });
  const { data } = adminClient.storage.from(BUCKET).getPublicUrl(path);
  res.json({ url: data.publicUrl, path });
});

app.get('/live', async (_req, res) => {
  const { data } = await adminClient.from('app_settings').select('value').eq('key', 'live_stream_url').maybeSingle();
  res.json({ url: data?.value || '' });
});

app.post('/push-token', async (req, res) => {
  const { token, platform } = req.body || {};
  if (!token || typeof token !== 'string' || token.length < 10) return res.status(400).json({ error: 'Push token is required' });
  const { error } = await adminClient.from('push_tokens').upsert({ token, platform: platform || 'unknown' }, { onConflict: 'token' });
  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true });
});

app.post('/notifications/breaking', requireUser, requireAdmin, async (req, res) => {
  const { title, body } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Notification title is required' });
  const { data: rows, error } = await adminClient.from('push_tokens').select('token');
  if (error) return res.status(500).json({ error: error.message });
  const messages = (rows || []).map(r => ({ to: r.token, sound: 'default', title, body: body || title, data: { type: 'breaking_news' } }));
  if (!messages.length) return res.json({ sent: 0 });
  const headers = { 'Content-Type': 'application/json' };
  if (EXPO_ACCESS_TOKEN) headers.Authorization = `Bearer ${EXPO_ACCESS_TOKEN}`;
  const response = await fetch('https://exp.host/--/api/v2/push/send', { method: 'POST', headers, body: JSON.stringify(messages) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) return res.status(502).json({ error: 'Expo push service error', details: payload });
  res.json({ sent: messages.length, result: payload });
});

app.listen(PORT, () => console.log(`UZ Online TV backend running on :${PORT}`));
