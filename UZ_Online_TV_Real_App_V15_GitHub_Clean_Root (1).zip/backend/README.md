# UZ Online TV Backend

This is the production API layer for the Expo mobile app. It uses Supabase for Auth, Postgres and Storage.

## Setup
1. Create a Supabase project.
2. Run `../supabase_schema.sql` in Supabase SQL Editor.
3. Run the extra SQL in `../supabase_production.sql`.
4. Create a Storage bucket named `news-images` and make it public (or replace `getPublicUrl` with signed URLs).
5. Create an admin user in Supabase Authentication.
6. Add that user's UUID to `admin_profiles` with role `admin`.
7. Copy `.env.example` to `.env` and fill in Supabase URL + service-role key.
8. `npm install`
9. `npm start`

Never put the Supabase service-role key inside the mobile app or `EXPO_PUBLIC_*` variables.
