const base = process.argv[2] || process.env.API_BASE_URL || 'http://localhost:8080';
const res = await fetch(`${base.replace(/\/$/, '')}/health`);
const body = await res.text();
if (!res.ok) throw new Error(`Health check failed: ${res.status} ${body}`);
console.log(body);
