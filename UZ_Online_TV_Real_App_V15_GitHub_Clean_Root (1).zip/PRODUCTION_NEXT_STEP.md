
# UZ Online TV — Production Backend

An ƙara API layer da Supabase-ready database schema.

## Yadda za a mayar da shi online
1. Create a Supabase project.
2. Run `supabase_schema.sql` in the SQL editor.
3. Create a secure admin account.
4. Put the backend/API URL in `services/api.ts`.
5. Connect the Admin screen to `publishNews()` and the News screen to `getNews()`.
6. Later add image storage, push notifications, and live stream settings.

## Important
Do not put Supabase service-role keys or private admin secrets inside the mobile app. Use a server/edge function for privileged operations.

## V7: Real Backend Wiring

The app now reads `EXPO_PUBLIC_API_BASE_URL` and uses the backend for news, programs, admin login and news-image uploads when that URL is configured. If it is empty, the app keeps a local demo fallback.

Backend source is in `backend/` and is designed for Supabase Auth + Postgres + Storage.

### Deployment order
1. Create Supabase project.
2. Run `supabase_schema.sql`, then `supabase_production.sql`.
3. Create `news-images` storage bucket.
4. Create an admin user in Supabase Authentication and insert its UUID into `admin_profiles`.
5. Deploy `backend/` to a Node 20 HTTPS host (Render, Railway, Fly.io, VPS, etc.).
6. Set `EXPO_PUBLIC_API_BASE_URL` to the deployed API URL.
7. Build with EAS after testing the API `/health` endpoint.

The Supabase service-role key belongs only on the backend server. Never place it in the Expo app.
