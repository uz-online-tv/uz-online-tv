# UZ Online TV V13 — iPhone-only cloud build

## Important
You do not need a Windows/Mac computer for the later cloud build steps, but Expo's current GitHub build documentation says a project must first have a successful EAS build from a local machine before GitHub-triggered builds are enabled. If you cannot access any computer even once, use a cloud computer such as GitHub Codespaces or another trusted browser-based development environment for that one-time initialization.

## Files already prepared
- Expo/React Native app
- Android package: com.uzonlinetv.app
- Preview profile creates APK
- Production profile creates AAB
- EAS workflow: `.eas/workflows/android-preview.yml`
- Android build image: latest

## What NOT to share
Never share your Expo password, verification code, Supabase service-role key, or GitHub password with anyone.

## After the project is connected to your Expo account
Use Expo's EAS dashboard to view the project and its Builds page. Expo's current docs support connecting a GitHub repository and then using **Build from GitHub** from the Builds page.
