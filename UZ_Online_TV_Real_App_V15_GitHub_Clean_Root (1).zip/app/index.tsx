
import React, { useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import * as Notifications from "expo-notifications";
import { adminSignIn, adminSignOut, getAdminSession } from "../services/auth";
import { addProgram as apiAddProgram, getNews, getPrograms, publishNews, uploadNewsImage } from "../services/api";
import {
  Image,
  Linking,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const FB = "https://www.facebook.com/share/1JqvGaK6U3/?mibextid=wwXIfr";

const news = [
  { id: 1, title: "Sabbin Labarai daga UZ Online TV", cat: "Local", time: "Yanzu" },
  { id: 2, title: "Muhimman abubuwan siyasa a yau", cat: "Politics", time: "Yau" },
  { id: 3, title: "Rahoton wasanni da sakamakon yau", cat: "Sports", time: "Yau" },
];

const defaultPrograms = [
  { day: "Litinin", time: "08:00", title: "Morning News" },
  { day: "Litinin", time: "12:00", title: "Labaran Rana" },
  { day: "Talata", time: "19:00", title: "Tattaunawa" },
  { day: "Laraba", time: "20:00", title: "Wasanni" },
];

export default function Home() {
  const [tab, setTab] = useState("Home");
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [newsItems, setNewsItems] = useState(news);
  const [programItems, setProgramItems] = useState(defaultPrograms);
  const [newTitle, setNewTitle] = useState("");
  const [newCategory, setNewCategory] = useState("Local");
  const [newProgram, setNewProgram] = useState("");
  const [newTime, setNewTime] = useState("");
  const [newDay, setNewDay] = useState("Litinin");
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);
  const [adminUser, setAdminUser] = useState("");
  const [adminPass, setAdminPass] = useState("");
  const [loginError, setLoginError] = useState("");
  const [newsImage, setNewsImage] = useState<string | null>(null);
  const [notificationsReady, setNotificationsReady] = useState(false);
  const [adminMessage, setAdminMessage] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const remoteNews = await getNews();
        if (remoteNews.length) setNewsItems(remoteNews as any);
      } catch {}
      try {
        const remotePrograms = await getPrograms();
        if (remotePrograms.length) setProgramItems(remotePrograms as any);
      } catch {}
      const session = await getAdminSession();
      if (session) setAdminLoggedIn(true);
      try {
        const perm = await Notifications.getPermissionsAsync();
        if (perm.status !== "granted") {
          const requested = await Notifications.requestPermissionsAsync();
          setNotificationsReady(requested.status === "granted");
        } else {
          setNotificationsReady(true);
        }
      } catch {}
    })();
  }, []);

  const saveNews = async (items: any[]) => {
    setNewsItems(items);
    await AsyncStorage.setItem("uz_news", JSON.stringify(items));
  };

  const savePrograms = async (items: any[]) => {
    setProgramItems(items);
    await AsyncStorage.setItem("uz_programs", JSON.stringify(items));
  };

  const adminLogin = async () => {
    setLoginError("");
    setAdminMessage("");
    try {
      const session = await adminSignIn(adminUser.trim(), adminPass);
      if (session) {
        setAdminLoggedIn(true);
        setAdminPass("");
      }
    } catch (e: any) {
      setLoginError(e?.message || "Login ya kasa. Duba bayanan ka.");
    }
  };

  const adminLogout = async () => {
    await adminSignOut();
    setAdminLoggedIn(false);
    setAdminUser("");
  };

  const pickNewsImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      quality: 0.85,
      allowsEditing: true,
      aspect: [16, 9],
    });
    if (!result.canceled && result.assets?.[0]?.uri) setNewsImage(result.assets[0].uri);
  };

  const sendBreakingNotification = async (title: string) => {
    if (!notificationsReady || !title.trim()) return;
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "UZ Online TV — Breaking News",
          body: title.trim(),
        },
        trigger: null,
      });
    } catch {}
  };

  const addNews = async () => {
    const title = newTitle.trim();
    if (!title) return;
    let imageUrl = newsImage || undefined;
    try {
      if (imageUrl) imageUrl = await uploadNewsImage(imageUrl);
      const created = await publishNews({ title, cat: newCategory as any, time: "Yanzu", imageUrl });
      setNewsItems([created as any, ...newsItems]);
      if (!process.env.EXPO_PUBLIC_API_BASE_URL) await AsyncStorage.setItem("uz_news", JSON.stringify([created, ...newsItems]));
    } catch (e: any) {
      if (process.env.EXPO_PUBLIC_API_BASE_URL) {
        setAdminMessage(e?.message || "An kasa wallafa labarin.");
        return;
      }
      const item = { id: Date.now(), title, cat: newCategory, time: "Yanzu", imageUrl };
      await saveNews([item, ...newsItems]);
    }
    await sendBreakingNotification(title);
    setNewTitle("");
    setNewsImage(null);
  };

  const addProgram = async () => {
    const title = newProgram.trim();
    if (!title || !newTime.trim()) return;
    try {
      const created = await apiAddProgram({ day: newDay, time: newTime.trim(), title });
      setProgramItems([...programItems, created]);
    } catch (e: any) {
      if (process.env.EXPO_PUBLIC_API_BASE_URL) {
        setAdminMessage(e?.message || "An kasa ƙara shirin.");
        return;
      }
      await savePrograms([...programItems, { day: newDay, time: newTime.trim(), title }]);
    }
    setNewProgram("");
    setNewTime("");
  };

  const filteredNews = useMemo(() => {
    return newsItems.filter((n) => {
      const catOk = category === "All" || n.cat === category;
      const qOk = n.title.toLowerCase().includes(query.toLowerCase());
      return catOk && qOk;
    });
  }, [category, query]);

  const openFacebook = () => Linking.openURL(FB);

  const renderHome = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <View style={styles.hero}>
        <View style={styles.heroRow}>
          <Image source={require("../assets/uz-online-tv-logo.png")} style={styles.logo} />
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>UZ ONLINE TV</Text>
            <Text style={styles.heroTitle}>Labaran Hausa, kai tsaye.</Text>
            <Text style={styles.heroSub}>News • Live • Programs • Videos</Text>
          </View>
        </View>
        <Pressable style={styles.liveButton} onPress={() => setTab("Live")}>
          <Ionicons name="play" size={18} color="#fff" />
          <Text style={styles.liveText}>Watch Live</Text>
        </Pressable>
      </View>

      <SectionTitle title="Breaking News" icon="flash" />
      <View style={styles.breaking}>
        <Ionicons name="flash" size={20} color="#fff" />
        <Text style={styles.breakingText}>Barka da zuwa UZ Online TV — za mu kawo muku sabbin labarai.</Text>
      </View>

      <SectionTitle title="Sabbin Labarai" icon="newspaper" />
      {newsItems.slice(0, 3).map((n) => <NewsCard key={n.id} item={n} />)}

      <SectionTitle title="TV Schedule" icon="calendar" />
      {programItems.slice(0, 3).map((p, i) => (
        <View key={i} style={styles.scheduleRow}>
          <View style={styles.timeBox}><Text style={styles.time}>{p.time}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.program}>{p.title}</Text>
            <Text style={styles.muted}>{p.day}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );

  const renderNews = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>News</Text>
      <TextInput
        value={query}
        onChangeText={setQuery}
        placeholder="Nemo labari..."
        placeholderTextColor="#7f8a9a"
        style={styles.search}
      />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
        {["All", "Local", "Politics", "Sports"].map((c) => (
          <Pressable key={c} onPress={() => setCategory(c)} style={[styles.chip, category === c && styles.chipActive]}>
            <Text style={[styles.chipText, category === c && styles.chipTextActive]}>{c}</Text>
          </Pressable>
        ))}
      </ScrollView>
      {filteredNews.map((n) => <NewsCard key={n.id} item={n} />)}
      {!filteredNews.length && <Text style={styles.muted}>Babu labarin da ya dace da binciken.</Text>}
    </ScrollView>
  );

  const renderLive = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>Live TV</Text>
      <View style={styles.player}>
        <Ionicons name="tv-outline" size={54} color="#fff" />
        <Text style={styles.playerTitle}>Live stream coming soon</Text>
        <Text style={styles.mutedCenter}>Za a saka live stream idan an shirya shi.</Text>
      </View>
      <View style={styles.infoCard}>
        <Text style={styles.cardTitle}>UZ Online TV</Text>
        <Text style={styles.muted}>Kalli shirye-shiryen tashar ku a nan idan live stream ya fara.</Text>
      </View>
    </ScrollView>
  );

  const renderVideos = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>Videos</Text>
      {["Sabon shirin UZ Online TV", "Tattaunawa ta yau", "Rahoton wasanni"].map((x, i) => (
        <View key={i} style={styles.videoCard}>
          <View style={styles.videoThumb}><Ionicons name="play-circle" size={48} color="#fff" /></View>
          <Text style={styles.cardTitle}>{x}</Text>
          <Text style={styles.muted}>UZ Online TV • Video</Text>
        </View>
      ))}
    </ScrollView>
  );

  const renderSchedule = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>TV Schedule</Text>
      {programItems.map((p, i) => (
        <View key={i} style={styles.scheduleRow}>
          <View style={styles.timeBox}><Text style={styles.time}>{p.time}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.program}>{p.title}</Text>
            <Text style={styles.muted}>{p.day}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );

  const renderAdmin = () => {
    if (!adminLoggedIn) {
      return (
        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.pageTitle}>Station Admin</Text>
          <View style={styles.loginCard}>
            <Ionicons name="lock-closed" size={42} color="#e21d2e" />
            <Text style={styles.loginTitle}>Admin Login</Text>
            <Text style={styles.mutedCenter}>Shiga domin wallafa labarai da shirye-shirye.</Text>
            <TextInput
              value={adminUser}
              onChangeText={setAdminUser}
              placeholder="Email"
              placeholderTextColor="#7f8a9a"
              autoCapitalize="none"
              style={styles.search}
            />
            <TextInput
              value={adminPass}
              onChangeText={setAdminPass}
              placeholder="Password"
              placeholderTextColor="#7f8a9a"
              secureTextEntry
              style={styles.search}
            />
            {loginError ? <Text style={styles.error}>{loginError}</Text> : null}
            <Pressable style={styles.adminButton} onPress={adminLogin}>
              <Ionicons name="log-in" size={20} color="#fff" />
              <Text style={styles.moreText}>Login</Text>
            </Pressable>
            {!process.env.EXPO_PUBLIC_API_BASE_URL ? <Text style={styles.demoHint}>Demo na offline: admin / UZTV2026</Text> : null}
          </View>
        </ScrollView>
      );
    }

    return (
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.adminHeader}>
          <View>
            <Text style={styles.pageTitle}>Station Admin</Text>
            <Text style={styles.muted}>Kana cikin admin dashboard.</Text>
            <Text style={styles.notificationStatus}>{notificationsReady ? "🔔 Notifications: Ready" : "🔕 Notifications: Not enabled"}</Text>
            {adminMessage ? <Text style={styles.error}>{adminMessage}</Text> : null}
          </View>
          <Pressable onPress={adminLogout} style={styles.logout}>
            <Ionicons name="log-out-outline" size={18} color="#fff" />
          </Pressable>
        </View>

        <View style={styles.adminCard}>
          <Text style={styles.cardTitle}>Add News</Text>
          <TextInput value={newTitle} onChangeText={setNewTitle} placeholder="Rubuta taken labari..." placeholderTextColor="#7f8a9a" style={styles.search} />
        <Pressable style={styles.imageButton} onPress={pickNewsImage}>
          <Ionicons name="image-outline" size={20} color="#fff" />
          <Text style={styles.moreText}>{newsImage ? "An zaɓi hoto" : "Zaɓi Hoton Labari"}</Text>
        </Pressable>
        {newsImage ? <Image source={{ uri: newsImage }} style={styles.previewImage} /> : null}
          <View style={styles.adminCats}>
            {["Local", "Politics", "Sports"].map(c => (
              <Pressable key={c} onPress={() => setNewCategory(c)} style={[styles.chip, newCategory === c && styles.chipActive]}>
                <Text style={[styles.chipText, newCategory === c && styles.chipTextActive]}>{c}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable style={styles.adminButton} onPress={addNews}>
            <Ionicons name="add-circle" size={20} color="#fff" />
            <Text style={styles.moreText}>Publish News</Text>
          </Pressable>
        </View>

        <View style={styles.adminCard}>
          <Text style={styles.cardTitle}>Add TV Program</Text>
          <TextInput value={newProgram} onChangeText={setNewProgram} placeholder="Sunan shiri..." placeholderTextColor="#7f8a9a" style={styles.search} />
          <TextInput value={newTime} onChangeText={setNewTime} placeholder="Lokaci, misali 20:00" placeholderTextColor="#7f8a9a" style={styles.search} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {["Litinin", "Talata", "Laraba", "Alhamis", "Jumma'a", "Asabar", "Lahadi"].map(d => (
              <Pressable key={d} onPress={() => setNewDay(d)} style={[styles.chip, newDay === d && styles.chipActive]}>
                <Text style={[styles.chipText, newDay === d && styles.chipTextActive]}>{d}</Text>
              </Pressable>
            ))}
          </ScrollView>
          <Pressable style={styles.adminButton} onPress={addProgram}>
            <Ionicons name="calendar" size={20} color="#fff" />
            <Text style={styles.moreText}>Add Program</Text>
          </Pressable>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.cardTitle}>Production security</Text>
          <Text style={styles.muted}>Wannan login ɗin demo ne. Kafin a saki app a Play Store/App Store, za a mayar da authentication zuwa secure online backend.</Text>
        </View>
      </ScrollView>
    );
  };

  const renderMore = () => (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.pageTitle}>More</Text>
      <View style={styles.infoCard}>
        <Text style={styles.cardTitle}>UZ Online TV</Text>
        <Text style={styles.muted}>Tashar labarai da shirye-shiryen Hausa.</Text>
      </View>
      <Pressable style={styles.moreButton} onPress={openFacebook}>
        <Ionicons name="logo-facebook" size={22} color="#fff" />
        <Text style={styles.moreText}>Facebook Page</Text>
      </Pressable>
      <View style={styles.infoCard}>
        <Text style={styles.cardTitle}>Breaking News</Text>
        <Text style={styles.muted}>An tanadi tsarin sanarwa domin manyan labarai.</Text>
      </View>
      <View style={styles.infoCard}>
        <Text style={styles.cardTitle}>About</Text>
        <Text style={styles.muted}>UZ Online TV — your digital TV platform.</Text>
      </View>
    </ScrollView>
  );

  const screen =
    tab === "Home" ? renderHome() :
    tab === "News" ? renderNews() :
    tab === "Live" ? renderLive() :
    tab === "Videos" ? renderVideos() :
    tab === "Schedule" ? renderSchedule() :
    tab === "Admin" ? renderAdmin() : renderMore();

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>{screen}</View>
      <View style={styles.nav}>
        {[
          ["Home", "home"],
          ["News", "newspaper"],
          ["Live", "radio"],
          ["Videos", "play-circle"],
          ["Schedule", "calendar"],
          ["Admin", "settings"],
          ["More", "menu"],
        ].map(([name, icon]) => (
          <Pressable key={name} style={styles.navItem} onPress={() => setTab(name)}>
            <Ionicons name={icon as any} size={21} color={tab === name ? "#e21d2e" : "#8c96a6"} />
            <Text style={[styles.navText, tab === name && styles.navActive]}>{name}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

function SectionTitle({ title, icon }: { title: string; icon: any }) {
  return (
    <View style={styles.sectionTitle}>
      <Ionicons name={icon} size={20} color="#e21d2e" />
      <Text style={styles.sectionText}>{title}</Text>
    </View>
  );
}

function NewsCard({ item }: any) {
  return (
    <View style={styles.newsCard}>
      {item.imageUrl ? (
        <Image source={{ uri: item.imageUrl }} style={styles.newsThumb} />
      ) : (
        <View style={styles.newsIcon}><Ionicons name="newspaper-outline" size={24} color="#fff" /></View>
      )}
      <View style={{ flex: 1 }}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.muted}>{item.cat} • {item.time}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#080b10" },
  container: { flex: 1, backgroundColor: "#080b10" },
  content: { padding: 18, paddingBottom: 110 },
  hero: { backgroundColor: "#111722", borderRadius: 22, padding: 18, marginBottom: 22, borderWidth: 1, borderColor: "#202837" },
  heroRow: { flexDirection: "row", alignItems: "center", gap: 14 },
  logo: { width: 74, height: 74, borderRadius: 14, backgroundColor: "#fff" },
  kicker: { color: "#e21d2e", fontWeight: "800", fontSize: 12, letterSpacing: 1.2 },
  heroTitle: { color: "#fff", fontSize: 25, fontWeight: "900", marginTop: 5 },
  heroSub: { color: "#aab3c2", marginTop: 6 },
  liveButton: { marginTop: 18, height: 48, backgroundColor: "#e21d2e", borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 },
  liveText: { color: "#fff", fontSize: 16, fontWeight: "800" },
  sectionTitle: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10, marginTop: 4 },
  sectionText: { color: "#fff", fontSize: 18, fontWeight: "800" },
  breaking: { backgroundColor: "#e21d2e", borderRadius: 14, padding: 13, flexDirection: "row", gap: 9, marginBottom: 20 },
  breakingText: { color: "#fff", flex: 1, lineHeight: 20, fontWeight: "600" },
  newsCard: { backgroundColor: "#111722", borderRadius: 15, padding: 13, marginBottom: 10, flexDirection: "row", gap: 12, borderWidth: 1, borderColor: "#1d2532" },
  newsIcon: { width: 46, height: 46, borderRadius: 12, backgroundColor: "#242d3c", alignItems: "center", justifyContent: "center" },
  cardTitle: { color: "#fff", fontWeight: "800", fontSize: 15, lineHeight: 21 },
  muted: { color: "#8f99a8", marginTop: 4, lineHeight: 19 },
  pageTitle: { color: "#fff", fontSize: 28, fontWeight: "900", marginBottom: 15 },
  search: { backgroundColor: "#111722", borderRadius: 13, paddingHorizontal: 15, height: 48, color: "#fff", marginBottom: 12, borderWidth: 1, borderColor: "#202837" },
  chip: { paddingHorizontal: 15, paddingVertical: 9, borderRadius: 20, backgroundColor: "#151c28", marginRight: 8 },
  chipActive: { backgroundColor: "#e21d2e" },
  chipText: { color: "#a8b0bd", fontWeight: "700" },
  chipTextActive: { color: "#fff" },
  player: { height: 230, borderRadius: 18, backgroundColor: "#10151e", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#202837" },
  playerTitle: { color: "#fff", fontSize: 18, fontWeight: "800", marginTop: 12 },
  mutedCenter: { color: "#8f99a8", marginTop: 5, textAlign: "center", paddingHorizontal: 25 },
  infoCard: { backgroundColor: "#111722", padding: 16, borderRadius: 15, marginTop: 14, borderWidth: 1, borderColor: "#202837" },
  videoCard: { backgroundColor: "#111722", borderRadius: 15, padding: 12, marginBottom: 12 },
  videoThumb: { height: 165, borderRadius: 12, backgroundColor: "#252d3a", alignItems: "center", justifyContent: "center", marginBottom: 10 },
  scheduleRow: { backgroundColor: "#111722", borderRadius: 14, padding: 13, marginBottom: 10, flexDirection: "row", alignItems: "center", gap: 12 },
  timeBox: { width: 62, height: 48, borderRadius: 10, backgroundColor: "#e21d2e", alignItems: "center", justifyContent: "center" },
  time: { color: "#fff", fontWeight: "900" },
  program: { color: "#fff", fontWeight: "800", fontSize: 15 },
  loginCard: { backgroundColor: "#111722", padding: 20, borderRadius: 18, alignItems: "center", borderWidth: 1, borderColor: "#202837" },
  loginTitle: { color: "#fff", fontSize: 23, fontWeight: "900", marginTop: 10, marginBottom: 5 },
  error: { color: "#ff5c67", marginBottom: 8, fontWeight: "700" },
  demoHint: { color: "#6f7a8a", fontSize: 11, marginTop: 12 },
  adminHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 },
  logout: { width: 42, height: 42, borderRadius: 12, backgroundColor: "#242d3c", alignItems: "center", justifyContent: "center" },
  adminCard: { backgroundColor: "#111722", padding: 16, borderRadius: 15, marginBottom: 14, borderWidth: 1, borderColor: "#202837" },
  adminCats: { flexDirection: "row", flexWrap: "wrap", marginBottom: 4 },
  imageButton: { backgroundColor: "#242d3c", padding: 13, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 10 },
  previewImage: { width: "100%", height: 150, borderRadius: 12, marginBottom: 10 },
  newsThumb: { width: 62, height: 62, borderRadius: 11 },
  notificationStatus: { color: "#9ba5b4", fontSize: 12, marginTop: 5 },
  adminButton: { backgroundColor: "#e21d2e", padding: 14, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 6 },
  moreButton: { backgroundColor: "#1877f2", padding: 15, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 10, marginTop: 14 },
  moreText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  nav: { position: "absolute", bottom: 0, left: 0, right: 0, height: 78, backgroundColor: "#0e131b", borderTopWidth: 1, borderTopColor: "#202837", flexDirection: "row", justifyContent: "space-around", paddingTop: 8 },
  navItem: { alignItems: "center", justifyContent: "center", flex: 1 },
  navText: { color: "#8c96a6", fontSize: 10, marginTop: 3, fontWeight: "700" },
  navActive: { color: "#e21d2e" },
});
