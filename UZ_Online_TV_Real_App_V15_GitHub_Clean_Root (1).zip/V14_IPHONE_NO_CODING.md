# UZ Online TV V14 — iPhone / No-Coding Cloud Build

## Goal
Build the Android APK from the cloud without a computer or Android Studio.

## One-time setup
1. Create a GitHub account at https://github.com/signup if you do not already have one.
2. Create a new repository named `uz-online-tv` (private is recommended).
3. Upload the contents of this project ZIP to the repository.
4. In Expo, open Account Settings > Access tokens and create a token. Never send the token to anyone.
5. In GitHub repository Settings > Secrets and variables > Actions, create secret `EXPO_TOKEN` and paste the Expo token there.

## Build from iPhone
Open the GitHub repository in Safari, tap **Actions**, choose **UZ Online TV Android Build**, tap **Run workflow**, choose `preview`, then run it.

The workflow runs EAS Build in the cloud. When it finishes, GitHub shows the build job and Expo/EAS provides the APK link.

## Production
Choose `production` only after the preview APK has been tested. Production produces an Android App Bundle (AAB) for Google Play.

## Security
- Never put an Expo token in source code.
- Never put a Supabase service-role key in the mobile app or GitHub repository.
- Use GitHub Actions Secrets for `EXPO_TOKEN`.
