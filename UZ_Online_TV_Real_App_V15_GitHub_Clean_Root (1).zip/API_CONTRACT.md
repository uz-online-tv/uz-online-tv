
# UZ Online TV Production API Contract

## Authentication
POST `/auth/login`
```json
{"email":"editor@example.com","password":"..."}
```
Returns:
```json
{"accessToken":"...","user":{"id":"...","email":"...","role":"admin"}}
```

## News
GET `/news`
POST `/news`
Headers: `Authorization: Bearer <accessToken>`

POST body:
```json
{
  "title":"...",
  "body":"...",
  "category":"Local",
  "imageUrl":"https://..."
}
```

## Programs
GET `/programs`
POST `/programs` (admin/editor)

## Push notifications
POST `/push-token`
Body:
```json
{"token":"ExponentPushToken[...]"}
```

POST `/notifications/breaking`
Admin only:
```json
{"title":"...", "body":"..."}
```

## Live
GET `/live`
Returns:
```json
{"enabled":false,"streamUrl":""}
```

Use HTTPS in production. Never ship a database service-role key inside the mobile app.
