This project is prepared for Expo EAS cloud builds.
Use the Expo dashboard / GitHub integration rather than editing this file.
