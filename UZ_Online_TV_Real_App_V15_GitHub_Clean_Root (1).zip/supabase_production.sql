-- Production additions for UZ Online TV
create extension if not exists pgcrypto;

create table if not exists admin_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','editor')) default 'editor',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists push_tokens (
  token text primary key,
  user_id uuid references auth.users(id) on delete cascade,
  platform text,
  created_at timestamptz not null default now()
);

alter table news enable row level security;
alter table programs enable row level security;
alter table videos enable row level security;
alter table breaking_news enable row level security;
alter table app_settings enable row level security;
alter table admin_profiles enable row level security;
alter table push_tokens enable row level security;

-- Public app reads. Writes stay behind the backend service role.
drop policy if exists "public read news" on news;
create policy "public read news" on news for select using (true);
drop policy if exists "public read programs" on programs;
create policy "public read programs" on programs for select using (true);
drop policy if exists "public read videos" on videos;
create policy "public read videos" on videos for select using (true);
drop policy if exists "public read breaking" on breaking_news;
create policy "public read breaking" on breaking_news for select using (true);
drop policy if exists "public read settings" on app_settings;
create policy "public read settings" on app_settings for select using (true);
