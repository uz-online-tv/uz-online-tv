# UZ Online TV — Images + Notifications

## Added in V5
- Admin can choose a news image from the phone gallery.
- News cards can display the selected image.
- The app requests notification permission.
- Publishing a news item can trigger a local breaking-news notification.

## Production requirement
For real notifications to every user, connect Expo Push Notifications (or Firebase/APNs through a backend). The backend must store device push tokens and send notifications securely.

For production image hosting, upload selected images to Supabase Storage/S3/Cloudinary and store the public URL in the news record instead of keeping a local phone URI.
