# UZ Online TV — V8 Production Backend + Build

## Abin da aka gyara
- Backend auth na Supabase + admin/editor role.
- News/program CRUD ta backend.
- News image upload zuwa Supabase Storage.
- Public push-token registration.
- Admin breaking-news push endpoint ta Expo Push Service.
- CORS environment setting.
- Mobile app ba ta koma local/demo data idan backend ya saita amma request ya fadi; za ta nuna kuskure maimakon ɓoye matsalar.
- Demo login yana bayyana ne kawai idan babu `EXPO_PUBLIC_API_BASE_URL`.

## Abin da ake bukata kafin real online launch
1. Create Supabase project.
2. Run `supabase_schema.sql` sannan `supabase_production.sql`.
3. Create public Storage bucket `news-images`.
4. Create admin user in Supabase Auth.
5. Insert that user's UUID into `admin_profiles` with role `admin`.
6. Deploy `backend/` to a Node 20 HTTPS host.
7. Put the backend URL into mobile build environment as `EXPO_PUBLIC_API_BASE_URL`.
8. Never put `SUPABASE_SERVICE_ROLE_KEY` inside the mobile app.

## Android build
Install EAS CLI on your own machine/account:

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile production
```

The production result can be an AAB for Google Play. For a directly installable APK, use a preview/internal profile or add an APK profile in `eas.json`.

## Important
This workspace cannot create a signed store-ready Android binary without access to the owner's Expo/EAS account and signing credentials. The source is build-ready, but deployment/signing still has to happen in the owner's account.
