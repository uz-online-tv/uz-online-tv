
# UZ Online TV V6 — Release Preparation

Completed:
- Admin authentication abstraction
- Session storage and logout
- Production API contract
- Environment variable template
- EAS build configuration
- Notification permission configuration

Still required before public store release:
1. Deploy a real HTTPS backend and database.
2. Replace the development auth fallback.
3. Configure real push notification delivery.
4. Connect production image storage.
5. Add privacy policy and terms pages.
6. Add final app icon/splash assets if desired.
7. Create Google Play Console and Apple Developer accounts.
8. Build signed Android AAB and iOS archive with EAS.
