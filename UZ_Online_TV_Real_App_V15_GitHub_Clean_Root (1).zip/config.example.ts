
export const APP_CONFIG = {
  stationName: "UZ Online TV",
  facebook: "https://www.facebook.com/share/1JqvGaK6U3/?mibextid=wwXIfr",
  liveStreamUrl: "",
  apiBaseUrl: "",
};
