# UZ Online TV — Mobile App

Expo / React Native app for UZ Online TV.

## Included
- Home, News, Videos, Live TV placeholder and TV Schedule
- News categories and search
- Admin login and protected admin area
- News image picker
- Local breaking-news notification
- Production API wiring for news/programs/admin login/image uploads
- Supabase schema and backend source
- EAS build configuration

## Demo mode
If `EXPO_PUBLIC_API_BASE_URL` is empty, the app uses local storage. Demo admin:
- Username: `admin`
- Password: `UZTV2026`

This is only for development. Use Supabase Auth + the backend before public release.

## Mobile app setup
```bash
npm install
npx expo start
```

For production, copy `.env.example` to `.env` and set:
`EXPO_PUBLIC_API_BASE_URL=https://YOUR-BACKEND.example.com`

## Backend setup
See `backend/README.md`.

## Build
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
eas build --platform android --profile production
eas build --platform ios --profile production
```

The project does not claim an APK/iOS build has already been produced. Those builds require an Expo/EAS account and signing credentials.
