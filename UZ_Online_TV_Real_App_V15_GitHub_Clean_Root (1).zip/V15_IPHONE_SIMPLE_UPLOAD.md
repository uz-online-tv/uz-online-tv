# UZ Online TV V15 — iPhone simple upload

This package is a clean repository root (no `v14work/` wrapper).

## Important
GitHub does not automatically extract a ZIP uploaded as a repository file. If you upload this ZIP itself, it will appear as one ZIP file. For a real build, the project files must be in the repository root.

### Easiest iPhone route
Use GitHub's web interface to create/upload the project files. If your GitHub interface only lets you upload the ZIP, stop there and do not start the build yet; use the included `V15_IPHONE_SIMPLE_UPLOAD.md` and the `.github/workflows/eas-build.yml` file after the project files are extracted into the repository.

### EAS build
After the project files are in the repository root, configure an Expo/EAS token as the GitHub Actions secret `EXPO_TOKEN`, then run the `Android Preview APK` workflow.

Do not put an Expo password, Supabase service-role key, or other secret in the repository.
