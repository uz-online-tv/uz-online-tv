# UZ Online TV — V16 Automatic Android Build

Wannan version an shirya shi domin ka daina amfani da terminal/CodeSpaces wajen build.

## Abin da workflow yake yi

1. Yana nemo `UZ_Online_TV_Real_App_V15_GitHub_Clean_Root.zip` a repository.
2. Yana bude ZIP din ta atomatik.
3. Yana gano Expo project.
4. Yana install dependencies.
5. Yana samar da Android project.
6. Yana build Release APK.
7. Yana ajiye APK a GitHub Actions **Artifacts** domin ka sauke shi.

## Abin da za ka yi a GitHub (ba terminal)

1. Ka shiga `uz-online-tv` repository.
2. Ka danna **Add file** → **Upload files**.
3. Ka saka folder/file:
   `.github/workflows/build-android-from-zip.yml`
4. Ka danna **Commit changes** zuwa `main`.
5. Je **Actions**.
6. Za ka ga **UZ Online TV - Automatic Android APK**.
7. Ka bude shi ka danna **Run workflow** (ko push na main ya fara shi automatically).
8. Idan ya gama da green check, bude run din → **Artifacts** → `UZ-Online-TV-Android-APK` → download.

### Muhimmi

- Wannan workflow baya bukatar `EXPO_TOKEN`.
- Ba ya bukatar ka rubuta `unzip` ko `ls` a terminal.
- ZIP din V15 ya kamata ya kasance a repository root da wannan sunan:
  `UZ_Online_TV_Real_App_V15_GitHub_Clean_Root.zip`
- Wannan yana gina **Android APK**. iPhone/App Store yana bukatar wani mataki daban daga baya.
